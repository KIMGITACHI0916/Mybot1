package main

import (
	"log"
	"os"
	"strings"
	"time"

	"github.com/tucnak/telebot"
	"tg-mgr/internal/handlers"
	"tg-mgr/internal/middleware"
)

func main() {
	token := os.Getenv("TELEGRAM_TOKEN")
	if token == "" {
		log.Fatal("TELEGRAM_TOKEN env missing")
	}

	adminsRaw := os.Getenv("ADMINS")
	admins := strings.Split(adminsRaw, ",")

	bot, err := telebot.NewBot(telebot.Settings{
		Token:  token,
		Poller: &telebot.LongPoller{Timeout: 10 * time.Second},
	})
	if err != nil {
		log.Fatal(err)
	}

	mw := middleware.NewMiddleware(admins)

	// User commands
	bot.Handle("/start", handlers.Start)
	bot.Handle("/help", handlers.Help)
	bot.Handle("/info", handlers.Info)

	// Tag all, supports: /al, /tagall, @all
	bot.Handle(telebot.OnText, handlers.TagAll(mw))

	// Admin commands
	adminCommands := map[string]telebot.HandlerFunc{
		"ban":     handlers.Ban,
		"unban":   handlers.Unban,
		"mute":    handlers.Mute,
		"unmute":  handlers.Unmute,
		"kick":    handlers.Kick,
		"sban":    handlers.SBan,
		"smute":   handlers.SMute,
		"skick":   handlers.SKick,
		"unsban":  handlers.Unsban,
		"unsmute": handlers.Unsmute,
		"purge":   handlers.Purge,
		"spurge":  handlers.SPurge,
		"pin":     handlers.Pin,
		"unpin":   handlers.Unpin,
		"tagall":  handlers.TagAll(mw),
	}
	for cmd, h := range adminCommands {
		bot.Handle("/"+cmd, mw.AdminOnly(h))
	}

	// Temporary commands: tmute, tban, etc.
	bot.Handle("/tmute", mw.AdminOnly(handlers.TMute))
	bot.Handle("/tban", mw.AdminOnly(handlers.TBan))

	// Anti-flood system
	bot.Use(mw.AntiFlood())

	log.Println("Bot started.")
	bot.Start()
}