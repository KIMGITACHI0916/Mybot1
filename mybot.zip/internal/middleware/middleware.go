package middleware

import (
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/tucnak/telebot"
)

type Middleware struct {
	admins      map[int64]bool
	floodCounts map[int64]int
	mu          sync.Mutex
	limit       int
	interval    time.Duration
}

func NewMiddleware(adminIDs []string) *Middleware {
	admins := make(map[int64]bool)
	for _, id := range adminIDs {
		if id == "" {
			continue
		}
		i, _ := strconv.ParseInt(id, 10, 64)
		admins[i] = true
	}
	limit := 5
	interval := 10 * time.Second
	if l := os.Getenv("FLOOD_LIMIT"); l != "" {
		if v, _ := strconv.Atoi(l); v > 0 {
			limit = v
		}
	}
	if t := os.Getenv("FLOOD_INTERVAL"); t != "" {
		if v, _ := strconv.Atoi(t); v > 0 {
			interval = time.Duration(v) * time.Second
		}
	}
	return &Middleware{
		admins:      admins,
		floodCounts: make(map[int64]int),
		limit:       limit,
		interval:    interval,
	}
}

func (mw *Middleware) IsAdmin(userID int64) bool {
	return mw.admins[userID]
}

func (mw *Middleware) AdminOnly(next telebot.HandlerFunc) telebot.HandlerFunc {
	return func(c telebot.Context) error {
		if !mw.IsAdmin(c.Sender().ID) {
			return c.Send("Admins only.")
		}
		return next(c)
	}
}

// Anti-flood middleware
func (mw *Middleware) AntiFlood() telebot.MiddlewareFunc {
	return func(next telebot.HandlerFunc) telebot.HandlerFunc {
		return func(c telebot.Context) error {
			uid := c.Sender().ID
			mw.mu.Lock()
			mw.floodCounts[uid]++
			count := mw.floodCounts[uid]
			mw.mu.Unlock()
			if count > mw.limit {
				return c.Send("You're sending messages too fast. Please slow down.")
			}
			go func() {
				time.Sleep(mw.interval)
				mw.mu.Lock()
				mw.floodCounts[uid]--
				mw.mu.Unlock()
			}()
			return next(c)
		}
	}
}

// Recognize tagall commands
func (mw *Middleware) IsTagAllCommand(text string) bool {
	lower := strings.ToLower(text)
	return strings.HasPrefix(lower, "/al") ||
		strings.HasPrefix(lower, "/tagall") ||
		strings.HasPrefix(lower, "@all")
}