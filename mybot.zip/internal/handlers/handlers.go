package handlers

import (
	"fmt"
	"strconv"
	"strings"

	"github.com/tucnak/telebot"
	"tg-mgr/internal/utils"
)

func Start(c telebot.Context) error {
	return c.Send("Welcome! Use /help to see commands.")
}

func Help(c telebot.Context) error {
	msg := "*Commands*\n" +
		"/info - Show your info\n" +
		"/al, /tagall, @all - Tag everyone (admins only)\n" +
		"/ban, /mute, /kick, etc. - Admin commands\n"
	return c.Send(msg, &telebot.SendOptions{ParseMode: telebot.ModeMarkdown})
}

func Info(c telebot.Context) error {
	u := c.Sender()
	// Telegram allows copy by click with markdown link
	userLink := fmt.Sprintf("[%s](tg://user?id=%d)", u.FirstName, u.ID)
	msg := fmt.Sprintf("User info:\nID: `%d`\nFirst Name: %s\nUsername: @%s\nUser link: %s",
		u.ID, u.FirstName, u.Username, userLink)
	return c.Send(msg, &telebot.SendOptions{ParseMode: telebot.ModeMarkdown})
}

func TagAll(mw *utils.Middleware) telebot.HandlerFunc {
	return func(c telebot.Context) error {
		text := c.Text()
		if !mw.IsTagAllCommand(text) {
			return nil
		}
		if !mw.IsAdmin(c.Sender().ID) {
			return nil
		}
		members, err := c.ChatMembers()
		if err != nil {
			return c.Send("Failed to fetch members.")
		}
		var tags []string
		for _, m := range members {
			if m.User.IsBot {
				continue
			}
			tags = append(tags, fmt.Sprintf("[%s](tg://user?id=%d)", m.User.FirstName, m.User.ID))
		}
		msg := "Wanna inform:\n" + strings.Join(tags, " - \n")
		return c.Send(msg, &telebot.SendOptions{ParseMode: telebot.ModeMarkdown})
	}
}

// --- Admin Handlers ---

func Ban(c telebot.Context) error    { return c.Send("Ban logic here.") }
func Unban(c telebot.Context) error  { return c.Send("Unban logic here.") }
func Mute(c telebot.Context) error   { return c.Send("Mute logic here.") }
func Unmute(c telebot.Context) error { return c.Send("Unmute logic here.") }
func Kick(c telebot.Context) error   { return c.Send("Kick logic here.") }

func SBan(c telebot.Context) error    { return c.Send("Silent ban logic here.") }
func SMute(c telebot.Context) error   { return c.Send("Silent mute logic here.") }
func SKick(c telebot.Context) error   { return c.Send("Silent kick logic here.") }
func Unsban(c telebot.Context) error  { return c.Send("Unsilent ban logic here.") }
func Unsmute(c telebot.Context) error { return c.Send("Unsilent mute logic here.") }

func Purge(c telebot.Context) error  { return c.Send("Purge logic here.") }
func SPurge(c telebot.Context) error { return c.Send("Silent purge logic here.") }

func Pin(c telebot.Context) error   { return c.Send("Pin logic here.") }
func Unpin(c telebot.Context) error { return c.Send("Unpin logic here.") }

func TMute(c telebot.Context) error { return c.Send("Temporary mute logic here.") }
func TBan(c telebot.Context) error  { return c.Send("Temporary ban logic here.") }